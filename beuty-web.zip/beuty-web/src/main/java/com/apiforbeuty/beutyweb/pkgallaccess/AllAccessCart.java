package com.apiforbeuty.beutyweb.pkgallaccess;

import com.apiforbeuty.beutyweb.pkgobj.ObjProduct;

import java.util.ArrayList;
import java.util.List;

public class AllAccessCart {

    public static List<ObjProduct> cart;
    static {
        cart =new ArrayList<ObjProduct>();

    }

}
